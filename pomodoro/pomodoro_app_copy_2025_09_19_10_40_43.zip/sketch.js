//DOM variabler - også kaldet DOM BINDINGS
var currentPage = '#page1'
var currentTodo = null
var currentTodoTitle = null 
// 24 minutter * 60 sec * 1000 milisec
const startTime = 24 * 60 * 1000
var pomodoroTimer
var currentTime = null 

//funktioen setup køre en gang når programmet starter. 
function setup() {
 noCanvas()
  //setTimeout( ()=> shiftPage('#page2'), 2000)
  shiftPage('#page2')
  //DOM BINDING of TODO 1
  currentTodo = select('#todo1')
  //HENT TEKSTEN INDE I TODO 1
  currentTodoTitle = select('#todo1 .todoTitle').html()
  //console.log(currentTodo, "This is what is inside currentTodo variable")
  currentTodo.mousePressed(  ()=> {
    startPomodoro()
  } )
  
}

function startPomodoro() {
  //sæt titlen på denne pomodoro
  select('#pomodoroTitle').html(currentTodoTitle)
  // lav minutter og sekunder
  currentTime = startTime 
  //var minutes = currentTime / 60000 
  pomodoroTimer = setInterval(showTime, 1000)
shiftPage('#page3')  
}

function showTime(){
  currentTime = currentTime - 1000
  var minutes = floor(currentTime / 60000)
    var seconds = currentTime
  console.log(minutes, 'Hej matematik')
  
}

function shiftPage( newPage ){
  //først fjern klassen show fra currentPage
  select(currentPage).removeClass('show')
  //sæt currentPage til funktionens argument
  currentPage = newPage
  //giv den nye side klasse 'show'
  select(currentPage).addClass('show')
}


