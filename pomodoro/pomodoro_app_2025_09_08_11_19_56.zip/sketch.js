//DOM variabler - også kaldet DOM BINDINGS
var currentPage  ="#page1"

//funktioen setup køre en gang når programmet starter. 
function setup() {
 noCanvas()
  //setTimeout( ()=> shiftPage('#page2'), 2000)
  shiftPage('#page2')
}

function shiftPage( newPage ){
  //først fjern klassen show fra currentPage
  select(currentPage).removeClass('show')
  //sæt currentPage til funktionens argument
  currentPage = newPage
  //giv den nye side klasse 'show'
  select(currentPage).addClass('show')
}


